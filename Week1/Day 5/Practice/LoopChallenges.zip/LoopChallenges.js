//1.printing odds
/*
for (var i = 1; i<21 ; i++) {
    console.log(i);
}
*/

//2.decreasing multiples of 3
/*
for (var i=100; i>0 ; i--) {
    if (i % 3 == 0) {
        console.log(i);
    }
}
*/

//3.print the sequence
/*
var arr = [4, 2.5, 1, -0.5, -2, -3.5];
for (var i = 0; i < arr.length; i++) {
    console.log(arr[i]);
}
*/

//4.Sigma
/*
var sum = 0;
for (var i = 1; i<101 ; i++) {
    sum = sum + i;
}
console.log(sum);
*/

//5.Factorial
var fact = 1;
for (var i = 1; i<13 ; i++) {
    fact = fact * i;
}
console.log(fact);